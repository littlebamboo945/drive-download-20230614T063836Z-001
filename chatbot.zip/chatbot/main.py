'''
import chatbot as bot

#test the response system
while True:
   print('Bot:' + bot.chatbot_2.get_response(input('You:')))
'''

#read data from paimon.txt and throw it into gpt_model
import paimon
file = open("paimon4_traditional_chinese.txt",'r',encoding="utf-8")
words = file.read()
print(words)
file.close()