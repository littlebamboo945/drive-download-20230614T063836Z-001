import random

R_EATING = "I don't eat anything"

def unknown():
    response = [
                'what does that mean?',
                 ][random.randrange(1)]
    return response
    