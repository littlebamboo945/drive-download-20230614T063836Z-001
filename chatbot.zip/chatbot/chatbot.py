def openai_function(res):
 import openai
 print("openai is called")
 str = res
 openai.organization = "chchchi"
 openai.api_key = "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"
 response = openai.Completion.create(
  model="text-davinci-003",
  prompt= str,
  temperature=1,
  max_tokens=400,
  top_p=0.75,
)
 completed_text=response["choices"][0]["text"]
 print("Bot:"+completed_text)
 
def chatbot_2():
 import re
 import long_response as long

 def message_probability(user_message, recognized_word, single_response = False, require_words = []):
    message_certainty = 0
    has_required_word = True
    
    #count words in message
    for word in user_message:
        if word in recognized_word:
            message_certainty += 1
    
    #calculate percentage of recognized_word in message
    percentage = float(message_certainty)/(float(len(recognized_word)))
    
    #check required words
    for word in require_words:
        if word not in user_message:
            has_required_word = False
            break
    
    if has_required_word or single_response:
        return int(percentage*100)   
    else:
        return 0 
    
 def check_all_message(message):
    highest_prob_list = {}
    
    def response(bot_response, list_of_words, single_response=False, required_words=[]):
        nonlocal highest_prob_list
        highest_prob_list[bot_response] = message_probability(message, list_of_words, single_response, required_words)
    
    #response
    response('hello', ['hello', 'hi', 'hey'], single_response=True)
    response('I\'m doing fine and you?', ['how', 'are', 'you', 'doing'], required_words=['how', 'are', 'you'])
    response('thank you', ['thank', 'you'], required_words=['thank'])
    response('I\'m coming', ['help', 'give', 'hand'], required_words=['help', 'me'])

    response(long.R_EATING, ['what', 'you', 'eat'], required_words=['you', 'eat'])
    
    best_match = max(highest_prob_list, key=highest_prob_list.get)
    #print(highest_prob_list)
    
    return long.unknown() if highest_prob_list[best_match]<1 else best_match
    
 def get_response(user_input):
    split_message = re.split(r'\s+|[,;?!.-]\s*', user_input.lower())
    response = check_all_message(split_message)
    return response

 #test the response system
 while True:
    ques = input('you:')
    res = get_response(ques)
    if(res == 'what does that mean?'):
        openai_function(ques)
    else:
     print('Bot:' + res)



chatbot_2()








    