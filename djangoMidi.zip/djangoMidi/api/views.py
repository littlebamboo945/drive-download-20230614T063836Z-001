from rest_framework.response import Response
from rest_framework.decorators import api_view


@api_view(['GET'])
def form(request):
    name = request.GET.get("name")
    gender = request.GET.get("gender")
    age = request.GET.get("age")
    exercise = request.GET.get("exercise")
    medical = request.GET.get("medical")
    uid = request.GET.get("uid")
    # print(name+gender+age+exercise+medical)
    # call bot
    # make data to json
    # return json
    datas = {
        "feeding":
            [
                {
                    "img_src": "1.png",
                    "title": "運動種類",
                    "content": "建議時數或其他"
                },
                {
                    "img_src": "2.png",
                    "title": "運動種類",
                    "content": "建議時數或其他"
                }
            ]
    }
    return Response(datas)


@api_view(['GET'])
def chat(request):
    # 要換成post要解決前後端分離的csrf-token問題
    uid = request.GET.get("uid")
    message = request.GET.get("message")
    datas = {
        "uid": "pymon",
        "message": "油膩豬陀"
    }
    # a = call pymon bot
    # 回傳格式:
    # {
    #        "uid":"pymon",
    #        "message":"油膩豬陀";
    # }
    return Response(datas)
