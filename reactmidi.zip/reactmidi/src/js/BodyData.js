import '../css/BodyData.css';
import React, { useState } from 'react';
import PopupObject from './Popup';

function BodyData(props) {
    //傳入參數
    //props.items,props.handleItemChange
    //State變數
    const [name, setName] = useState("");
    const [gender, setGender] = useState("");
    const [age, setAge] = useState("")
    const [excerise, setExcercise] = useState("")
    const [medical, setMedical] = useState("")

    //ajax表單提交(可再優化?)
    // const [isSubmit, setIsSubmit] = useState(false);
    // const [isLoaded, setIsLoaded] = useState(false);
    // const [error, setError] = useState(null);


    const handleClick = (name, gender, age, exercise, medical, uid = props.uid) => {
        // setIsSubmit(true);
        setName(name);
        setGender(gender);
        setAge(age);
        setExcercise(exercise);
        setMedical(medical);
        let url = `http://127.0.0.1:8000/api/?format=json&name=${name}&gender=${gender}&age=${age}&exercise=${exercise}&medical=${medical}&uid=${uid}`;
        fetch(url)
            .then(res => res.json())
            .then(
                // 正確
                (result) => {
                    console.log(result);
                    // setIsLoaded(true);
                    props.handleItemChange(result);
                },
                // 錯誤
                (error) => {
                    console.log(error);
                    // setIsLoaded(true);
                    // setError(error);
                }
            )
    }

    // // 若已提交表單，檢視目前狀態為1.錯誤 2.正在抓取資料 3.已抓取完成
    // useEffect(() => {
    //     if (!isSubmit) {
    //         setContent("輸入資料以查看");
    //     }
    //     else if (!isLoaded) {
    //         setContent("is loading");
    //     }
    //     else if (error) {
    //         setContent(error);
    //     } else {
    //         setContent(props.items.a + " " + props.items.b);
    //     }
    // }, [isSubmit, isLoaded, error, props.items]);

    return (
        <div>
            <div className="BodyData">
                <div className="section"><BodyPicture /></div>
                <div className="section"><BodyStatus name={name} gender={gender} age={age} exercise={excerise} medical={medical} /></div>
                <div className="section"><BodyPicture /></div>
                {/* <div className="section"><Information content={content} /></div> */}
                {/* 不要了 */}
            </div>
            <PopupObject handleClick={handleClick} />
        </div >
    );
}

function BodyStatus(props) {
    return (
        <div>
            <h3>身體數據</h3>
            <div>{props.name}</div>
            <div>{props.gender}</div>
            <div>{props.age}</div>
            <div>{props.exercise}</div>
            <div>{props.medical}</div>
        </div>
    )
}

function BodyPicture() {
    return <img src={process.env.PUBLIC_URL + "/body.jpg"} alt="ImageOfBodyStaus" />
}

// function Information(props) {
//     if (props.content === 'undefined') {
//         return <h3>詳細資料</h3>;
//     } else if (typeof props.content === 'string') {
//         return (
//             <div>
//                 <h3>詳細資料</h3>
//                 <div>{props.content}</div>
//             </div>
//         );
//     } else {
//         return <h3>通訊發生錯誤</h3>;
//     }
// }


export default BodyData;