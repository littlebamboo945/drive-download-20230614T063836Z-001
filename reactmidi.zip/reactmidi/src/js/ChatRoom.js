import React, { useState, useEffect } from 'react';
import '../css/ChatRoom.css';

//聊天室按鈕(關閉狀態)
function ChatRoom(props) {
    const [isChatRoomVisible, setIsChatRoomVisible] = useState(false);
    return (
        <div className="chatRoom">
            <button className="chatButton" onClick={() => setIsChatRoomVisible(!isChatRoomVisible)}>聊天室</button>
            <ChatRoomCanvas trigger={isChatRoomVisible} setButtonPop={setIsChatRoomVisible} uid={props.uid} />
        </div>
    );
}


function ChatRoomCanvas(props) {
    //變數宣告
    const [message, setMessage] = useState(""); //對話框中的訊息
    const [messages, setMessages] = useState([]);   //歷史對話

    //當form表單value改變，更新對應的變數
    const handleChange = (event) => {
        setMessage(event.target.value);
    }

    //表單提交時執行
    const handleSubmit = (event) => {
        event.preventDefault();
        sendMessage(props.uid, message)//傳送至後端
        setMessage("");//清空輸入框
    };

    //處理表單的傳送
    const sendMessage = (uid, message) => {
        addMessage({ "uid": uid, "message": message });
        let url = `http://127.0.0.1:8000/api/chat/?format=json&message=${message}&uid=${uid}`;
        fetch(url)
            .then(res => res.json())
            .then(
                // 正確
                (result) => {
                    addMessage(result);
                },
                // 錯誤
                (error) => {
                    console.log(error);
                }
            )
    }

    //在歷史對話中加入新訊息
    const addMessage = (result) => {
        setMessages((prevMessages) => [...prevMessages, result]);
    };

    //將json轉可顯示在網頁上的html
    let messageContent = messages.map((value, key) => <MessageLine key={key} message={value} />);

    //表單
    return props.trigger ? (
        <div>
            <div className="messageBoard">
                {messageContent}
            </div>
            <div className="messageBoxContainer">
                <form onSubmit={handleSubmit}>
                    <input className="messageBox" required="required" type="text" name="message" autoComplete="off" value={message} onChange={handleChange} />
                    <input type="submit" hidden />
                </form>
            </div>
        </div>
    ) : "";
}

function MessageLine(props) {
    if (props.message.uid === 'pymon')
        return (
            <div className="messageLine">
                <div className="userName">派蒙:</div>
                <div className="test">
                    <div className="message">{props.message.message}</div>
                    <div className="box"></div>
                </div>
            </div >
        )
    else
        return (
            <div className="messageLine">
                <div className="userName">使用者:</div>
                <div className="test">
                    <div className="message">{props.message.message}</div>
                </div>
            </div >
        )
}


export default ChatRoom;