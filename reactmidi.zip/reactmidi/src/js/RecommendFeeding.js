import '../css/RecommendFeeding.css';

function RecommendFeeding(props) {
    // props.items
    let list = props.items.feeding;//get somthing here 表單的東西要傳到這裡
    let content = list.map((value, key) => <NewsPost key={key} feed={value} />)
    return <div className="RecommendFeeding">
        <h1>建議運動</h1>
        <div className="NewsRow">
            {content}
        </div>
    </div>
}

function NewsPost(props) {
    return <div className="NewsPost">
        <div className="imgEx">{props.feed.img_src}</div>
        <div>{props.feed.title}</div>
        <div>{props.feed.content}</div>
    </div>
}

export default RecommendFeeding;
