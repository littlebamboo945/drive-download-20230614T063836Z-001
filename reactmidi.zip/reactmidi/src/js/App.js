import BodyData from './BodyData';
import RecommendFeeding from './RecommendFeeding';
import ChatRoom from './ChatRoom';
import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
function App() {
  const uid = uuidv4();
  console.log(uid);
  return (
    <div className="App">
      <Head />
      <Body uid={uid} />
      <Footer />
      <ChatRoom uid={uid} />
    </div>
  );
}


function Head() {
  return (
    <div className="Header">
      <div>Header</div>
    </div>
  );
}

function Footer() {
  return (
    <div className="Footer">
      <div>produce by Team Stan</div>
      <div>2023.03.15</div>
    </div>
  );
}

function Body(props) {

  const [items, setItems] = useState({
    "feeding": [
      {
        "img_src": "1.png",
        "title": "運動種類",
        "content": "建議時數或其他"
      },
      {
        "img_src": "2.png",
        "title": "運動種類",
        "content": "建議時數或其他"
      }
    ]
  });

  const handleItemChange = (value) => {
    setItems(value);
  }

  return (
    <div className="Body">
      <BodyData items={items} handleItemChange={handleItemChange} uid={props.uid} />
      <RecommendFeeding items={items} />
    </div>
  )
}

export default App;
