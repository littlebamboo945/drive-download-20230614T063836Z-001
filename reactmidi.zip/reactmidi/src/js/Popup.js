import React, { useState } from 'react';
import '../css/Popup.css'

function PopupObject(props) {
    const [ButtonPop, setButtonPop] = useState(false);
    return (
        <div>
            <button onClick={() => setButtonPop(true)}>輸入身體資料</button>
            <Popup trigger={ButtonPop} setButtonPop={setButtonPop} handleFormAjax={props.handleFormAjax} handleClick={props.handleClick} />
        </div>
    )
}

function Popup(props) {
    //變數宣告
    const [formName, setFormName] = useState("");
    const [formGender, setFormGender] = useState("male");
    const [formAge, setFormAge] = useState("21-30")
    const [formExercise, setFormExcercise] = useState("")
    const [formMedical, setFormMedical] = useState("")


    //當form表單value改變，更新對應的變數
    const handleChange = (event) => {
        switch (event.target.name) {
            case "name":
                setFormName(event.target.value);
                break;
            case "gender":
                setFormGender(event.target.value);
                break;
            case "age":
                setFormAge(event.target.value);
                break;
            case "exercise":
                setFormExcercise(event.target.value);
                break;
            case "medical":
                setFormMedical(event.target.value);
                break;
            default:
                console.log("error");
        }
    }

    //表單提交時執行
    const handleSubmit = (event) => {
        event.preventDefault();
        props.handleClick(formName, formGender, formAge, formExercise, formMedical);
        props.setButtonPop(false);
    };

    //表單
    return props.trigger ? (
        <div className="popup">
            <div className="popup-inner">
                <button className="close-btn" onClick={() => props.setButtonPop(false)}>
                    x
                </button>

                <form onSubmit={handleSubmit}>
                    <div>
                        Name:
                        <input type="text" name="name" value={formName} onChange={handleChange} />
                    </div>
                    <div>
                        Gender:
                        <select name="gender" value={formGender} onChange={handleChange}>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>
                    <div>
                        age:
                        <select name="age" value={formAge} onChange={handleChange}>
                            <option value="21~30">21~30</option>
                            <option value="31~40">31~40</option>
                            <option value="41~50">41~50</option>
                            <option value="51~60">51~60</option>
                        </select>
                    </div>
                    <div>
                        prefer exercise:
                        <input type="text" value={formExercise} onChange={handleChange} name="exercise" />
                    </div>
                    <div>
                        medical history:
                        <input type="text" value={formMedical} onChange={handleChange} name="medical" />
                    </div>
                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>
    ) : "";
}



export default PopupObject;